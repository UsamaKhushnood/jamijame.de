<template>
  <section class="our-work">
    <div style="width: 75%; margin: 0 auto;">
      <div class="row">
        <div class="col-lg-12">
          <div class="our-work-wrapp d-flex justify-content-between align-items-center">
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0zip.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>ZIP CODE</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0create-signal.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>CREATE REQUEST</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0proposal.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>PROPOSAL</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0book-partyservice.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>BOOK PARTY SERVICE</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0create-public.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>CREATE PUBLIC OFFER</h3>
                </div>
              </div>
            </div>

            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/PARTY-SECTION/0feedback.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>GIVE FEEDBACK</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  name: "HomePartyServiceSection",
};
</script>