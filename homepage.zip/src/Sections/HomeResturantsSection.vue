<template>
  <section class="our-work">
    <div style="width: 75%; margin: 0 auto;">
      <div class="row">
        <div class="col-lg-12">
          <div class="our-work-wrapp d-flex justify-content-between align-items-center">
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0zip.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>RESTURANTS</h3>
                </div>
              </div>
            </div>

            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0resturant-section.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>RESTURANTS</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0table.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>TABLE RESERVATION</h3>
                </div>
              </div>
            </div>
            <!-- <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0place.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>PLACE RESERVATION</h3>
                </div>
              </div>
            </div>-->

            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0enjoy-dinner.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>ENJOY DINNER</h3>
                </div>
              </div>
            </div>
            <div class="single-work w-100">
              <div class="single-work-thumb">
                <figure>
                  <img src="@/assets/images/RESTURANT-SECTION/0feedback.png" alt />
                </figure>
                <div class="imgText">
                  <h3>SELECT A</h3>
                  <h3>FEEDBACK</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  name: "HomeResturantsSection",
};
</script>